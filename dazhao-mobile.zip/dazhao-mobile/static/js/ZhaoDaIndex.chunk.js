webpackJsonp([0],{

/***/ 550:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _react = __webpack_require__(0);

var _react2 = _interopRequireDefault(_react);

var _AnswerMain = __webpack_require__(119);

var _AnswerMain2 = _interopRequireDefault(_AnswerMain);

__webpack_require__(554);

var _ajax = __webpack_require__(4);

var _ajax2 = _interopRequireDefault(_ajax);

var _reactRouter = __webpack_require__(3);

var _LoadingMore = __webpack_require__(120);

var _LoadingMore2 = _interopRequireDefault(_LoadingMore);

var _LoadingBlock = __webpack_require__(559);

var _LoadingBlock2 = _interopRequireDefault(_LoadingBlock);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var ZhaoDaIndex = function (_React$Component) {
    _inherits(ZhaoDaIndex, _React$Component);

    function ZhaoDaIndex(props) {
        _classCallCheck(this, ZhaoDaIndex);

        var _this2 = _possibleConstructorReturn(this, (ZhaoDaIndex.__proto__ || Object.getPrototypeOf(ZhaoDaIndex)).call(this, props));

        _this2.state = {
            "pressDownX": 0, // 鼠标按下的位置
            "nowX": 0, // 鼠标移动后的位置
            "delateX": 0, // 移动的距离
            "currentX": 0,
            "latestDynamic": [],
            "hotTopic": [],
            "popularityPople": [
                // {
                //     "id": 1,
                //     "imgsrc": "/src/images/topicImg.png",
                //     "name": "Michael",
                //     "position": "骨灰级猎头、WIT总裁"
                // }
            ],
            "latestZhuanlan": [
                // {
                //     "tid": "2",
                //     "colposter": "/src/images/zhuanlan.png",
                //     "colposterbig": "/src/images/zhuanlan.png",
                //     "colid": "1",
                //     "coldescription": "简历，不简单！该如何写？要注意哪些地方？请听——光爸说",
                //     "colname": "#光爸说# 第一期——写简历的正确姿势"
                // }
            ],
            "carouselpic": [
                // {
                //     "id": "3",
                //     "img": "/src/images/1487917069l108992947.png",
                //     "description": "图片一"
                // }
            ],
            "nowshow": 0,
            "getmore": false,
            "latestDynamicPage": 1,
            "nomore": false,
            "lock": false,
            "loading1": true,
            "loading2": true,
            "loading3": true

        };
        _this2.fetchHotTopic = _this2.fetchHotTopic.bind(_this2);
        _this2.fetchLatestZhuanlan = _this2.fetchLatestZhuanlan.bind(_this2);
        _this2.fetchLatestDynamic = _this2.fetchLatestDynamic.bind(_this2);
        _this2.fetchPopularity = _this2.fetchPopularity.bind(_this2);
        _this2.fetchCarouselpic = _this2.fetchCarouselpic.bind(_this2);

        return _this2;
    }

    _createClass(ZhaoDaIndex, [{
        key: "componentDidMount",
        value: function componentDidMount() {
            var _this3 = this;

            [this.refs.topic1, this.refs.topic2, this.refs.topic3].map(function (elem) {

                _this3._touchEvent(elem);
            });

            // 轮播
            var autoCarousel = setInterval(function () {

                var nowshow = JSON.parse(JSON.stringify(_this3.state)).nowshow;

                nowshow === _this3.state.carouselpic.length - 1 ? nowshow = 0 : nowshow++;

                _this3.setState({ nowshow: nowshow });
            }, 4000);

            this.setState({ autoCarousel: autoCarousel });

            this.fetchHotTopic();
            this.fetchLatestZhuanlan();
            this.fetchLatestDynamic();
            this.fetchCarouselpic();
        }
    }, {
        key: "componentWillUnmount",
        value: function componentWillUnmount() {

            this.setState({ "lock": true });

            clearInterval(this.state.autoCarousel);
        }

        // 获取轮播图片

    }, {
        key: "fetchCarouselpic",
        value: function fetchCarouselpic() {
            var _this4 = this;

            (0, _ajax2.default)({
                "url": "/zhaoda/carouselpic",
                "obj": this
            }).then(function (data) {

                if (!_this4.state.lock) {

                    if (data.code === "S01") {

                        _this4.setState({ "carouselpic": data.contents });
                    } else if (data.code === "E01") {

                        _this4.setState({ "carouselpic": _this4.state.carouselpic });
                    }
                }
            });
        }

        // 最新动态

    }, {
        key: "fetchLatestDynamic",
        value: function fetchLatestDynamic() {
            var _this5 = this;

            (0, _ajax2.default)({
                "url": "/zhaoda/zhaoda/boutiqueanswer?page=" + this.state.latestDynamicPage,
                "obj": this
            }).then(function (data) {

                if (!_this5.state.lock) {

                    console.log(data);
                    if (data.contents.length > 0) {

                        var newQ = _this5.state.latestDynamic;

                        data.contents.map(function (value) {

                            newQ.push({
                                "qid": value.question.qid,
                                "aid": value.aid,
                                "topic": value.question.topics,
                                "theme": value.question.qtitle,
                                "name": value.user.nickname,
                                "vip": value.user.vip,
                                "remark": value.remark,
                                "agree": value.question.agree,
                                "comment": value.content,
                                "collect": value.collect,
                                "job": value.user.position
                            });
                            _this5.setState({
                                "latestDynamic": newQ,
                                "getmore": true
                            });
                        });
                    } else {

                        _this5.setState({
                            "getmore": true,
                            "nomore": true
                        });
                    }
                }
            });
        }

        // 加载更多

    }, {
        key: "getMore",
        value: function getMore() {
            var _this6 = this;

            this.setState({
                "latestDynamicPage": parseInt(this.state.latestDynamicPage) + 1,
                "getmore": false
            }, function () {

                _this6.fetchLatestDynamic();
            });
        }

        // 热门话题

    }, {
        key: "fetchHotTopic",
        value: function fetchHotTopic() {
            var _this7 = this;

            (0, _ajax2.default)({
                "url": "/zhaoda/topic/hottopics?categoryid=-1",
                "obj": this
            }).then(function (data) {

                if (!_this7.state.lock) {

                    if (data.code === "S01") {

                        // 查询成功
                        var hotTopic = data.contents.slice(0, 5);

                        _this7.setState({
                            hotTopic: hotTopic,
                            "loading1": false
                        });
                    } else if (data.code === "E01") {

                        // 如果查询出错，启用备用数据
                        _this7.setState({ "hotTopic": _this7.state.hotTopic });
                    }
                }
            });
        }

        // 人气行家

    }, {
        key: "fetchPopularity",
        value: function fetchPopularity() {}

        // 最新专栏

    }, {
        key: "fetchLatestZhuanlan",
        value: function fetchLatestZhuanlan() {
            var _this8 = this;

            (0, _ajax2.default)({
                "url": "/zhaoda/zhuanlan/lastestzhuanlan?page=-1",
                "obj": this
            }).then(function (data) {

                if (!_this8.state.lock) {

                    if (data.code === "S01") {

                        var zhuanlan = data.contents.slice(0, 5);

                        _this8.setState({
                            "latestZhuanlan": zhuanlan,
                            "loading3": false
                        });
                    } else if (data.code === "E01") {

                        // 如果查询出错，启用备用数据
                        _this8.setState({ "latestZhuanlan": _this8.state.latestZhuanlan });
                    }
                }
            });
        }

        // 滑动事件

    }, {
        key: "_touchEvent",
        value: function _touchEvent(elem) {
            var _this9 = this;

            // 触屏开始
            elem.addEventListener("touchstart", function (e) {

                // E.preventDefault();
                var _this = elem;
                var isStart = true;
                var event = e || window.event;
                var pressDownX = event.touches[0].pageX;
                var left = parseInt(_this.style.left || _this.offsetLeft);

                _this9.setState({
                    pressDownX: pressDownX,
                    "currentX": left
                });

                // 触屏移动
                _this.addEventListener("touchmove", function (e) {

                    e.preventDefault();
                    if (isStart) {

                        var _left = _this9.state.currentX;
                        var element = _this;
                        var width = element.clientWidth;
                        var windowWidth = window.innerWidth;
                        var _event = e || window.event;

                        _this9.setState({
                            "nowX": _event.touches[0].pageX,
                            "delateX": _event.touches[0].pageX - _this9.state.pressDownX
                        });
                        _left += _this9.state.delateX;

                        // 边界判断
                        if (windowWidth > width) {

                            return;
                        }

                        if (_left > windowWidth - width - 10 && _left < 0) {

                            element.style.left = _left + "px";
                        } else if (_left < windowWidth - width - 10) {

                            element.style.left = windowWidth - width - 10 + "px";
                        } else if (_left > 0) {

                            element.style.left = "0px";
                        }
                    }
                });

                // 触屏结束
                _this.addEventListener("touchend", function () {

                    e.preventDefault();
                    if (isStart) {

                        var element = _this;
                        var currentX = parseInt(element.style.left);

                        _this9.setState({
                            "pressDownX": 0,
                            "nowX": 0,
                            currentX: currentX,
                            "delateX": 0
                        });
                    }
                    isStart = false;
                });
            });
        }
    }, {
        key: "render",
        value: function render() {
            var _this10 = this;

            var _state = this.state,
                latestDynamic = _state.latestDynamic,
                hotTopic = _state.hotTopic,
                popularityPople = _state.popularityPople,
                latestZhuanlan = _state.latestZhuanlan,
                carouselpic = _state.carouselpic,
                nowshow = _state.nowshow,
                getmore = _state.getmore,
                nomore = _state.nomore,
                loading1 = _state.loading1,
                loading2 = _state.loading2,
                loading3 = _state.loading3;


            var AnswerMainList = latestDynamic.map(function (value, i) {
                return _react2.default.createElement(_AnswerMain2.default, { key: i, data: value });
            });

            var hotTopicList = hotTopic.map(function (elem, index) {
                return _react2.default.createElement(
                    "div",
                    { className: "img", key: index },
                    _react2.default.createElement(
                        _reactRouter.Link,
                        { to: "/totopic/" + elem.tid },
                        _react2.default.createElement(
                            "span",
                            { className: "span1" },
                            _react2.default.createElement("img", { src: "/src/images/topicImg.png" || elem.img, alt: "\u70ED\u95E8\u8BDD\u9898" })
                        ),
                        _react2.default.createElement(
                            "span",
                            { className: "span2" },
                            elem.topicname
                        ),
                        _react2.default.createElement(
                            "span",
                            { className: "care" },
                            _react2.default.createElement(
                                "span",
                                null,
                                "\u56DE\u7B54:",
                                elem.questionnum
                            ),
                            _react2.default.createElement(
                                "span",
                                null,
                                "\u5173\u6CE8:",
                                elem.care
                            )
                        )
                    )
                );
            });

            var popularityPopleList = popularityPople.map(function (elem, index) {
                return _react2.default.createElement(
                    "div",
                    { className: "img", key: index },
                    _react2.default.createElement(
                        "span",
                        { className: "span1" },
                        _react2.default.createElement("img", { src: elem.imgsrc, alt: "\u4EBA\u6C14\u884C\u5BB6" })
                    ),
                    _react2.default.createElement(
                        "span",
                        { className: "span2" },
                        elem.name
                    ),
                    _react2.default.createElement(
                        "span",
                        { className: "care" },
                        elem.position
                    )
                );
            });

            var latestZhuanlanList = latestZhuanlan.map(function (elem, index) {
                return _react2.default.createElement(
                    "div",
                    { className: "img", key: index },
                    _react2.default.createElement(
                        _reactRouter.Link,
                        { to: "tofeature?colid=" + elem.colid },
                        _react2.default.createElement("img", { src: "/src/images/zhuanlan.png" || elem.colposter }),
                        _react2.default.createElement(
                            "p",
                            null,
                            elem.colname
                        )
                    )
                );
            });

            var carouselpicList = carouselpic.map(function (elem, index) {
                return index === nowshow ? _react2.default.createElement(
                    "div",
                    { className: "item active", key: index },
                    _react2.default.createElement("img", { src: "/src/images/1487917069l108992947.png" || elem.img, alt: elem.description })
                ) : "";
            });
            var carouselOlList = carouselpic.map(function (elem, index) {
                return index === nowshow ? _react2.default.createElement("li", { key: index, className: "active" }) : _react2.default.createElement("li", { onClick: function onClick() {

                        _this10.setState({ "nowshow": index });
                    }, key: index
                });
            });

            return _react2.default.createElement(
                "div",
                { className: "ZhaoDaIndex" },
                _react2.default.createElement(
                    "div",
                    { id: "show" },
                    _react2.default.createElement(
                        "div",
                        { id: "myCarousel", className: "carousel slide", "data-ride": "carousel" },
                        _react2.default.createElement(
                            "ol",
                            { className: "carousel-indicators" },
                            carouselOlList
                        ),
                        _react2.default.createElement(
                            "div",
                            { className: "carousel-inner" },
                            carouselpicList
                        )
                    )
                ),
                _react2.default.createElement(
                    "div",
                    { id: "latest" },
                    _react2.default.createElement(
                        "div",
                        { className: "title" },
                        _react2.default.createElement(
                            "span",
                            null,
                            _react2.default.createElement("img", { src: "/src/images/latest.png" })
                        ),
                        "\u6700\u65B0\u52A8\u6001"
                    ),
                    AnswerMainList,
                    nomore ? "" : _react2.default.createElement(
                        "div",
                        { className: "Formore", onClick: function onClick() {

                                _this10.getMore();
                            }
                        },
                        !getmore ? _react2.default.createElement(_LoadingMore2.default, null) : "加载更多"
                    ),
                    nomore ? _react2.default.createElement(
                        "p",
                        { className: "nomore" },
                        "\u6CA1\u6709\u66F4\u591A\u4E86..."
                    ) : ""
                ),
                _react2.default.createElement(
                    "div",
                    { id: "moreTopic" },
                    _react2.default.createElement(
                        "div",
                        { className: "topic topic1" },
                        _react2.default.createElement(
                            "div",
                            { className: "head" },
                            _react2.default.createElement(
                                "span",
                                { className: "hot" },
                                _react2.default.createElement(
                                    "b",
                                    null,
                                    _react2.default.createElement("img", { src: "/src/images/hot.png" })
                                ),
                                "\u70ED\u95E8\u8BDD\u9898"
                            ),
                            _react2.default.createElement(
                                _reactRouter.Link,
                                { to: "/topic" },
                                _react2.default.createElement(
                                    "span",
                                    { className: "all" },
                                    "\u5168\u90E8\u8BDD\u9898",
                                    _react2.default.createElement("b", null),
                                    _react2.default.createElement("img", { src: "/src/images/seeMore.png" })
                                )
                            )
                        ),
                        _react2.default.createElement(
                            "div",
                            { id: "topic1", ref: "topic1", className: "content" },
                            loading1 ? _react2.default.createElement(_LoadingBlock2.default, null) : hotTopicList
                        )
                    ),
                    _react2.default.createElement(
                        "div",
                        { className: "topic topic2" },
                        _react2.default.createElement(
                            "div",
                            { className: "head" },
                            _react2.default.createElement(
                                "span",
                                { className: "hot" },
                                _react2.default.createElement(
                                    "b",
                                    null,
                                    _react2.default.createElement("img", { src: "/src/images/special.png" })
                                ),
                                "\u4EBA\u6C14\u884C\u5BB6"
                            ),
                            _react2.default.createElement(
                                _reactRouter.Link,
                                { to: "" },
                                _react2.default.createElement(
                                    "span",
                                    { className: "all" },
                                    "\u5168\u90E8\u884C\u5BB6",
                                    _react2.default.createElement(
                                        "b",
                                        null,
                                        _react2.default.createElement("img", { src: "/src/images/seeMore.png" })
                                    )
                                )
                            )
                        ),
                        _react2.default.createElement(
                            "div",
                            { id: "topic2", ref: "topic2", className: "content" },
                            loading2 ? _react2.default.createElement(_LoadingBlock2.default, null) : popularityPopleList
                        )
                    ),
                    _react2.default.createElement(
                        "div",
                        { className: "topic topic3" },
                        _react2.default.createElement(
                            "div",
                            { className: "head" },
                            _react2.default.createElement(
                                "span",
                                { className: "hot" },
                                _react2.default.createElement(
                                    "b",
                                    null,
                                    _react2.default.createElement("img", { src: "/src/images/special.png" })
                                ),
                                "\u6700\u65B0\u4E13\u680F"
                            ),
                            _react2.default.createElement(
                                _reactRouter.Link,
                                { to: "/Zhaoda/feature" },
                                _react2.default.createElement(
                                    "span",
                                    { className: "all" },
                                    "\u5168\u90E8\u4E13\u680F",
                                    _react2.default.createElement(
                                        "b",
                                        null,
                                        _react2.default.createElement("img", { src: "/src/images/seeMore.png" })
                                    )
                                )
                            )
                        ),
                        _react2.default.createElement(
                            "div",
                            { id: "topic3", ref: "topic3", className: "content" },
                            loading3 ? _react2.default.createElement(_LoadingBlock2.default, null) : latestZhuanlanList
                        )
                    )
                ),
                _react2.default.createElement(
                    "p",
                    { className: "bottom" },
                    "\u53CD\u9988\u5EFA\u8BAE \xB7 \u6210\u4E3A\u884C\u5BB6 \xB7 \u95EE\u7B54\u662F\u4EC0\u4E48"
                )
            );
        }
    }]);

    return ZhaoDaIndex;
}(_react2.default.Component);

exports.default = ZhaoDaIndex;

/***/ }),

/***/ 551:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(555);
if(typeof content === 'string') content = [[module.i, content, '']];
// add the styles to the DOM
var update = __webpack_require__(1)(content, {});
if(content.locals) module.exports = content.locals;
// Hot Module Replacement
if(false) {
	// When the styles change, update the <style> tags
	if(!content.locals) {
		module.hot.accept("!!../../../../node_modules/.0.26.4@css-loader/index.js?minimize!../../../../node_modules/.6.0.6@sass-loader/lib/loader.js!./LoadingBlock.scss", function() {
			var newContent = require("!!../../../../node_modules/.0.26.4@css-loader/index.js?minimize!../../../../node_modules/.6.0.6@sass-loader/lib/loader.js!./LoadingBlock.scss");
			if(typeof newContent === 'string') newContent = [[module.id, newContent, '']];
			update(newContent);
		});
	}
	// When the module is disposed, remove the <style> tags
	module.hot.dispose(function() { update(); });
}

/***/ }),

/***/ 554:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(558);
if(typeof content === 'string') content = [[module.i, content, '']];
// add the styles to the DOM
var update = __webpack_require__(1)(content, {});
if(content.locals) module.exports = content.locals;
// Hot Module Replacement
if(false) {
	// When the styles change, update the <style> tags
	if(!content.locals) {
		module.hot.accept("!!../../../../node_modules/.0.26.4@css-loader/index.js?minimize!../../../../node_modules/.6.0.6@sass-loader/lib/loader.js!./ZhaoDaIndex.scss", function() {
			var newContent = require("!!../../../../node_modules/.0.26.4@css-loader/index.js?minimize!../../../../node_modules/.6.0.6@sass-loader/lib/loader.js!./ZhaoDaIndex.scss");
			if(typeof newContent === 'string') newContent = [[module.id, newContent, '']];
			update(newContent);
		});
	}
	// When the module is disposed, remove the <style> tags
	module.hot.dispose(function() { update(); });
}

/***/ }),

/***/ 555:
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(2)();
// imports


// module
exports.push([module.i, ".block{padding-top:.12rem!important}.block .item{background:#f8f8f8;width:80%;margin:0 auto;margin-bottom:.08rem;height:.2rem}", ""]);

// exports


/***/ }),

/***/ 558:
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(2)();
// imports


// module
exports.push([module.i, ".ZhaoDaIndex{width:100%;overflow:hidden;margin-bottom:.72rem}.ZhaoDaIndex #show{width:100%;height:1.5rem;background:#d3d3d3;position:relative}.ZhaoDaIndex #show ol{list-style:none}.ZhaoDaIndex #show .item{width:100%;height:1.5rem;position:absolute;left:0;top:0}.ZhaoDaIndex #show img{width:100%;height:1.5rem;background:#333}.ZhaoDaIndex #show .carousel-indicators{width:100%;height:.2rem;display:flex;position:absolute;justify-content:center;bottom:.02rem}.ZhaoDaIndex #show .carousel-indicators li{width:.08rem;height:.08rem;border-radius:50%;background:#fff;margin:0 .05rem;z-index:9999}.ZhaoDaIndex #show .carousel-indicators .active{background:#adadad}.ZhaoDaIndex #latest{width:100%;padding-bottom:.63rem;background:#f8f8f8}.ZhaoDaIndex #latest .title{font-size:.16rem;font-weight:700;color:#666;background:#f8f8f8;display:flex;align-items:center;padding:.13rem .14rem .14rem}.ZhaoDaIndex #latest .title img{width:.15rem;height:.18rem;display:flex;float:left;margin-right:.06rem}.ZhaoDaIndex #latest article{width:100%;padding:0 .13rem;box-sizing:border-box;margin-bottom:.14rem;border-top:.01rem solid #d8d8d8;border-bottom:.01rem solid #d8d8d8;background:#fff}.ZhaoDaIndex #latest article .topic{width:100%;display:flex;font-size:.13rem;font-family:\\\\82F9\\65B9;color:#adadad;margin:.16rem 0}.ZhaoDaIndex #latest article .topic i{font-style:normal}.ZhaoDaIndex #latest article .theme{width:100%;font-size:.16rem;font-family:\\\\82F9\\65B9;font-weight:700;color:#333;line-height:.24rem}.ZhaoDaIndex #latest article .publisher{width:100%;font-size:.14rem;font-family:\\\\82F9\\65B9;font-weight:700;margin-top:.16rem;color:#696969;line-height:.2rem;display:flex;align-items:center}.ZhaoDaIndex #latest article .publisher .vip,.ZhaoDaIndex #latest article .publisher img{width:.16rem;height:.16rem}.ZhaoDaIndex #latest article .publisher .vip{margin-left:.03rem;display:inline-block}.ZhaoDaIndex #latest article .publisher span{font-size:.14rem;font-family:\\\\82F9\\65B9;color:#adadad;font-weight:400}.ZhaoDaIndex #latest article .comment{width:100%;font-size:.14rem;font-family:\\\\82F9\\65B9;line-height:.25rem;color:#666;margin:.15rem 0}.ZhaoDaIndex #latest article .comment span{position:relative;display:block}.ZhaoDaIndex #latest article .comment span img{width:80%;height:.3rem}.ZhaoDaIndex #latest article .comment span .start{position:absolute;left:.15rem;top:.05rem}.ZhaoDaIndex #latest article .comment span .start img{width:.2rem;height:.2rem}.ZhaoDaIndex #latest article .comment span b{display:block;width:.3rem;font-style:normal;line-height:.3rem;float:right;margin-right:.1rem;font-weight:400}.ZhaoDaIndex #latest article .more{width:100%;font-size:.14rem;font-family:\\\\82F9\\65B9;color:#adadad;margin:.15rem 0;line-height:.2rem}.ZhaoDaIndex #latest article .more span{display:inline-flex;align-items:center;margin-right:.2rem}.ZhaoDaIndex #latest article .more span b{display:inline-block;width:.16rem;height:.16rem;margin-right:.06rem}.ZhaoDaIndex #latest article .more img{width:.15rem;height:.15rem}.ZhaoDaIndex #latest .Formore{width:92%;height:.4rem;border:.01rem solid #21c5cd;color:#21c5cd;font-size:.14rem;text-align:center;line-height:.4rem;border-radius:.05rem;margin:.3rem auto 0;background:#fff}.ZhaoDaIndex #latest .Formore a{color:#21c5cd}.ZhaoDaIndex #latest .nomore{font-size:.14rem;color:#adadad;text-align:center}.ZhaoDaIndex #moreTopic{width:100%;padding:0 .08rem;box-sizing:border-box;background:#f8f8f8;-webkit-touch-callout:none;-webkit-user-select:none;-khtml-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none}.ZhaoDaIndex #moreTopic .head{display:flex;align-items:center;position:relative}.ZhaoDaIndex #moreTopic .head .hot{font-size:.16rem;font-family:\\\\82F9\\65B9;font-weight:700;color:#666}.ZhaoDaIndex #moreTopic .head .hot img{width:.23rem;height:.16rem;margin-right:.06rem}.ZhaoDaIndex #moreTopic .head .all{font-size:.13rem;font-family:\\\\82F9\\65B9;color:#21c5cd;position:absolute;right:0;cursor:pointer}.ZhaoDaIndex #moreTopic .head .all img{width:.1rem;height:.13rem;margin-left:.06rem}.ZhaoDaIndex #moreTopic .head img{width:.16rem;height:.16rem}.ZhaoDaIndex #moreTopic .content{margin-bottom:.2rem;margin-top:.2rem;position:relative}.ZhaoDaIndex #moreTopic .content .img{width:1.6rem;height:1.65rem;box-sizing:border-box;border-radius:.03rem;box-shadow:0 0 .06rem rgba(0,0,0,.15);background:#fff;padding-top:.14rem;margin-right:.1rem;font-size:0}.ZhaoDaIndex #moreTopic .content .img .span1{display:block;background:#dadada;margin:0 auto}.ZhaoDaIndex #moreTopic .content .img .span1,.ZhaoDaIndex #moreTopic .content .img .span1 img{width:.75rem;height:.75rem;border-radius:.05rem}.ZhaoDaIndex #moreTopic .content .img .span2{display:block;font-size:.14rem;font-family:\\\\82F9\\65B9;font-weight:700;color:#333;text-align:center;margin:.17rem 0 .08rem}.ZhaoDaIndex #moreTopic .content .img .care{display:block;text-align:center;font-size:.14rem;font-family:\\\\82F9\\65B9;color:#333;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.ZhaoDaIndex #moreTopic .content .img .care span:first-child{margin-right:.08rem}.ZhaoDaIndex #moreTopic .topic2 .img .span1{border-radius:50%}.ZhaoDaIndex #moreTopic .topic2 .img .span1 img{width:.75rem;height:.75rem;border-radius:50%}.ZhaoDaIndex #moreTopic .topic3 .content .img{padding-top:0;border-radius:.03rem;white-space:normal}.ZhaoDaIndex #moreTopic .topic3 .content .img img{width:1.6rem;height:1.1rem;border-radius:.03rem .03rem 0 0}.ZhaoDaIndex #moreTopic .topic3 .content .img p{font-size:.13rem;font-family:\\\\82F9\\65B9;color:#666;line-height:.19rem;text-align:left;padding:0 .1rem;margin-top:.11rem;overflow:hidden;text-overflow:ellipsis;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical}.ZhaoDaIndex .bottom{font-size:.15rem;font-family:\\\\82F9\\65B9;color:#adadad;line-height:.19rem;text-align:center}", ""]);

// exports


/***/ }),

/***/ 559:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _react = __webpack_require__(0);

var _react2 = _interopRequireDefault(_react);

__webpack_require__(551);

var _reactRouter = __webpack_require__(3);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var LoadingBlock = function (_React$Component) {
    _inherits(LoadingBlock, _React$Component);

    function LoadingBlock(props) {
        _classCallCheck(this, LoadingBlock);

        return _possibleConstructorReturn(this, (LoadingBlock.__proto__ || Object.getPrototypeOf(LoadingBlock)).call(this, props));
    }

    _createClass(LoadingBlock, [{
        key: "render",
        value: function render() {

            return _react2.default.createElement(
                "div",
                null,
                _react2.default.createElement(
                    "div",
                    { className: "block img" },
                    _react2.default.createElement("div", { className: "item" }),
                    _react2.default.createElement("div", { className: "item" }),
                    _react2.default.createElement("div", { className: "item" }),
                    _react2.default.createElement("div", { className: "item" }),
                    _react2.default.createElement("div", { className: "item" })
                ),
                _react2.default.createElement(
                    "div",
                    { className: "block img" },
                    _react2.default.createElement("div", { className: "item" }),
                    _react2.default.createElement("div", { className: "item" }),
                    _react2.default.createElement("div", { className: "item" }),
                    _react2.default.createElement("div", { className: "item" }),
                    _react2.default.createElement("div", { className: "item" })
                ),
                _react2.default.createElement(
                    "div",
                    { className: "block img" },
                    _react2.default.createElement("div", { className: "item" }),
                    _react2.default.createElement("div", { className: "item" }),
                    _react2.default.createElement("div", { className: "item" }),
                    _react2.default.createElement("div", { className: "item" }),
                    _react2.default.createElement("div", { className: "item" })
                ),
                _react2.default.createElement(
                    "div",
                    { className: "block img" },
                    _react2.default.createElement("div", { className: "item" }),
                    _react2.default.createElement("div", { className: "item" }),
                    _react2.default.createElement("div", { className: "item" }),
                    _react2.default.createElement("div", { className: "item" }),
                    _react2.default.createElement("div", { className: "item" })
                ),
                _react2.default.createElement(
                    "div",
                    { className: "block img" },
                    _react2.default.createElement("div", { className: "item" }),
                    _react2.default.createElement("div", { className: "item" }),
                    _react2.default.createElement("div", { className: "item" }),
                    _react2.default.createElement("div", { className: "item" }),
                    _react2.default.createElement("div", { className: "item" })
                )
            );
        }
    }]);

    return LoadingBlock;
}(_react2.default.Component);

exports.default = LoadingBlock;

/***/ })

});