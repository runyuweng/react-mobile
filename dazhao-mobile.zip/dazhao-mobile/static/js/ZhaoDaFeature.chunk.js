webpackJsonp([1],{

/***/ 549:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _react = __webpack_require__(0);

var _react2 = _interopRequireDefault(_react);

__webpack_require__(553);

var _reactRouter = __webpack_require__(3);

var _ajax = __webpack_require__(4);

var _ajax2 = _interopRequireDefault(_ajax);

var _Loading = __webpack_require__(15);

var _Loading2 = _interopRequireDefault(_Loading);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var ZhaoDaFeature = function (_React$Component) {
    _inherits(ZhaoDaFeature, _React$Component);

    function ZhaoDaFeature(props) {
        _classCallCheck(this, ZhaoDaFeature);

        var _this = _possibleConstructorReturn(this, (ZhaoDaFeature.__proto__ || Object.getPrototypeOf(ZhaoDaFeature)).call(this, props));

        _this.state = {
            "zhuanlan": [],
            "showLoading": true
        };
        _this.fetchLatestZhuanlan = _this.fetchLatestZhuanlan.bind(_this);

        return _this;
    }

    _createClass(ZhaoDaFeature, [{
        key: "componentDidMount",
        value: function componentDidMount() {

            this.fetchLatestZhuanlan();
        }

        // 专栏信息

    }, {
        key: "fetchLatestZhuanlan",
        value: function fetchLatestZhuanlan() {
            var _this2 = this;

            (0, _ajax2.default)({ "url": "/zhaoda/zhuanlan/lastestzhuanlan?page=-1" }).then(function (data) {

                console.log(data);
                if (data.code === "S01") {

                    var zhuanlan = data.contents;

                    _this2.setState({
                        zhuanlan: zhuanlan,
                        "showLoading": false
                    });
                }
            });
        }
    }, {
        key: "render",
        value: function render() {
            var _state = this.state,
                zhuanlan = _state.zhuanlan,
                showLoading = _state.showLoading;


            var ZhuanLanList = zhuanlan.map(function (elem, index) {
                return _react2.default.createElement(
                    "div",
                    { className: "feature", key: index },
                    _react2.default.createElement(
                        _reactRouter.Link,
                        { to: {
                                "pathname": "tofeature",
                                "query": { "colid": elem.colid }
                            }
                        },
                        _react2.default.createElement(
                            "div",
                            { className: "featureImg" },
                            _react2.default.createElement("img", { src: "/src/images/zhuanlan.png" || elem.colposterbig })
                        ),
                        _react2.default.createElement(
                            "span",
                            { className: "fTheme" },
                            elem.colname
                        )
                    ),
                    _react2.default.createElement(
                        "div",
                        { className: "publisher" },
                        _react2.default.createElement("span", { className: "cicle" }),
                        "Michael" || elem.name,
                        elem.vip ? _react2.default.createElement(
                            "span",
                            { className: "vip" },
                            _react2.default.createElement("img", { src: "/src/images/vip.png" })
                        ) : ""
                    ),
                    _react2.default.createElement(
                        "p",
                        null,
                        elem.coldescription
                    )
                );
            });

            return _react2.default.createElement(
                "div",
                null,
                showLoading ? _react2.default.createElement(_Loading2.default, null) : _react2.default.createElement(
                    "div",
                    { className: "ZhaoDaFeature" },
                    ZhuanLanList
                )
            );
        }
    }]);

    return ZhaoDaFeature;
}(_react2.default.Component);

exports.default = ZhaoDaFeature;

/***/ }),

/***/ 553:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(557);
if(typeof content === 'string') content = [[module.i, content, '']];
// add the styles to the DOM
var update = __webpack_require__(1)(content, {});
if(content.locals) module.exports = content.locals;
// Hot Module Replacement
if(false) {
	// When the styles change, update the <style> tags
	if(!content.locals) {
		module.hot.accept("!!../../../../node_modules/.0.26.4@css-loader/index.js?minimize!../../../../node_modules/.6.0.6@sass-loader/lib/loader.js!./ZhaoDaFeature.scss", function() {
			var newContent = require("!!../../../../node_modules/.0.26.4@css-loader/index.js?minimize!../../../../node_modules/.6.0.6@sass-loader/lib/loader.js!./ZhaoDaFeature.scss");
			if(typeof newContent === 'string') newContent = [[module.id, newContent, '']];
			update(newContent);
		});
	}
	// When the module is disposed, remove the <style> tags
	module.hot.dispose(function() { update(); });
}

/***/ }),

/***/ 557:
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(2)();
// imports


// module
exports.push([module.i, ".ZhaoDaFeature{background:#ececec;margin-bottom:.72rem}.ZhaoDaFeature .feature{width:100%;background:#fff;border-bottom:.01rem solid #adadad;padding:0 .125rem .15rem;box-sizing:border-box;position:relative;margin-bottom:.15rem}.ZhaoDaFeature .feature .featureImg{margin-bottom:-.07rem}.ZhaoDaFeature .feature .featureImg img{width:100%;margin-top:.15rem}.ZhaoDaFeature .feature .fTheme{font-family:\\\\82F9\\65B9;font-weight:700;font-size:.14rem}.ZhaoDaFeature .feature .fTheme,.ZhaoDaFeature .feature .publisher{color:#333;display:flex;justify-content:center;margin-bottom:.14rem}.ZhaoDaFeature .feature .publisher{font-size:.13rem;align-items:center}.ZhaoDaFeature .feature .publisher .cicle{display:inline-block;width:.24rem;height:.24rem;border-radius:50%;background:#adadad;margin-right:.06rem}.ZhaoDaFeature .feature .publisher .vip,.ZhaoDaFeature .feature .publisher img{width:.16rem;height:.16rem}.ZhaoDaFeature .feature .publisher .vip{margin-left:.04rem;display:inline-block}.ZhaoDaFeature .feature p{padding:0 .12rem;font-size:.12rem;line-height:.18rem;text-align:center;color:#adadad}", ""]);

// exports


/***/ })

});