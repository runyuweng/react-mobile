webpackJsonp([2],{

/***/ 548:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _react = __webpack_require__(0);

var _react2 = _interopRequireDefault(_react);

var _AnswerMain = __webpack_require__(119);

var _AnswerMain2 = _interopRequireDefault(_AnswerMain);

__webpack_require__(552);

var _Loading = __webpack_require__(15);

var _Loading2 = _interopRequireDefault(_Loading);

var _reactRouter = __webpack_require__(3);

var _ajax = __webpack_require__(4);

var _ajax2 = _interopRequireDefault(_ajax);

var _LoadingMore = __webpack_require__(120);

var _LoadingMore2 = _interopRequireDefault(_LoadingMore);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var ZhaoDaDiscover = function (_React$Component) {
    _inherits(ZhaoDaDiscover, _React$Component);

    function ZhaoDaDiscover(props) {
        _classCallCheck(this, ZhaoDaDiscover);

        var _this = _possibleConstructorReturn(this, (ZhaoDaDiscover.__proto__ || Object.getPrototypeOf(ZhaoDaDiscover)).call(this, props));

        _this.state = {
            "showLoading": true,
            "hotTopics": [],
            "goodAnswer": [],
            "page": 1,
            "nomore": false,
            "getmore": false
        };
        _this.fetchHotTopic = _this.fetchHotTopic.bind(_this);
        _this.fetchGoodAnswer = _this.fetchGoodAnswer.bind(_this);

        return _this;
    }

    _createClass(ZhaoDaDiscover, [{
        key: "componentDidMount",
        value: function componentDidMount() {

            this.fetchHotTopic();
            this.fetchGoodAnswer(this.state.page);
        }

        // 精品回答

    }, {
        key: "fetchGoodAnswer",
        value: function fetchGoodAnswer() {
            var _this2 = this;

            (0, _ajax2.default)({
                "url": "/zhaoda/zhaoda/boutiqueanswer?page=" + this.state.page,
                "obj": this
            }).then(function (data) {

                if (data.code === "S01") {

                    // Console.log(typeof this.state.page)
                    var newQ = _this2.state.goodAnswer;
                    var page = parseInt(_this2.state.page, 10) + 1;

                    data.contents.map(function (value) {

                        newQ.push({
                            "qid": value.question.qid,
                            "aid": value.aid,
                            "topic": value.question.topics,
                            "theme": value.question.qtitle,
                            "name": value.user.nickname,
                            "vip": value.user.vip,
                            "remark": value.remark,
                            "agree": value.question.agree,
                            "comment": value.content,
                            "collect": value.collect,
                            "job": value.user.position
                        });
                        _this2.setState({
                            "goodAnswer": newQ,
                            "getmore": true
                        });
                    });
                } else if (data.code === "S02") {

                    var _newQ = _this2.state.goodAnswer;

                    data.contents.map(function (value) {

                        _newQ.push({
                            "qid": value.question.qid,
                            "aid": value.aid,
                            "topic": value.question.topics,
                            "theme": value.question.qtitle,
                            "name": value.user.nickname,
                            "vip": value.user.vip,
                            "remark": value.remark,
                            "agree": value.question.agree,
                            "comment": value.content,
                            "collect": value.collect,
                            "job": value.user.position
                        });
                    });
                    _this2.setState({
                        "goodAnswer": _newQ,
                        "getmore": true,
                        "nomore": true
                    });
                } else {

                    console.log("E01");
                }
            });
        }

        // 加载更多

    }, {
        key: "getMore",
        value: function getMore() {
            var _this3 = this;

            this.setState({
                "page": parseInt(this.state.page) + 1,
                "getmore": false
            }, function () {

                _this3.fetchGoodAnswer();
            });
        }

        // 热门话题

    }, {
        key: "fetchHotTopic",
        value: function fetchHotTopic() {
            var _this4 = this;

            (0, _ajax2.default)({ "url": "/zhaoda/topic/hottopics?categoryid=-1" }).then(function (data) {

                if (data.code === "S01") {

                    // 查询成功
                    var hotTopic = data.contents.slice(0, 10);

                    _this4.setState({
                        "hotTopics": hotTopic,
                        "showLoading": false
                    });
                } else if (data.code === "E01") {

                    // 如果查询出错，启用备用数据
                    _this4.setState({ "hotTopics": _this4.state.hotTopics });
                }
            });
        }
    }, {
        key: "render",
        value: function render() {
            var _this5 = this;

            var _state = this.state,
                goodAnswer = _state.goodAnswer,
                hotTopics = _state.hotTopics,
                nomore = _state.nomore,
                getmore = _state.getmore,
                showLoading = _state.showLoading;


            var AnswerMainList = goodAnswer.map(function (value, i) {
                return _react2.default.createElement(_AnswerMain2.default, { isTopic: "0", key: i, data: value });
            });

            var LatestDynamicList = hotTopics.map(function (elem, index) {
                return _react2.default.createElement(
                    "div",
                    { className: "Citems", key: index },
                    _react2.default.createElement(
                        _reactRouter.Link,
                        { to: "/totopic/" + elem.tid },
                        _react2.default.createElement(
                            "span",
                            { className: "img" },
                            _react2.default.createElement("img", { src: "/src/images/topicImg.png" || elem.img, alt: "\u70ED\u95E8\u8BDD\u9898" })
                        ),
                        _react2.default.createElement(
                            "div",
                            { className: "detail" },
                            _react2.default.createElement(
                                "span",
                                { className: "span2" },
                                elem.topicname
                            ),
                            _react2.default.createElement(
                                "span",
                                { className: "care" },
                                _react2.default.createElement(
                                    "span",
                                    null,
                                    "\u56DE\u7B54:",
                                    elem.questionnum
                                ),
                                _react2.default.createElement(
                                    "span",
                                    null,
                                    "\u5173\u6CE8:",
                                    elem.care
                                )
                            )
                        )
                    )
                );
            });

            return _react2.default.createElement(
                "div",
                null,
                showLoading ? _react2.default.createElement(_Loading2.default, null) : _react2.default.createElement(
                    "div",
                    { className: "ZhaoDaDiscover" },
                    _react2.default.createElement(
                        "div",
                        { id: "dynamic" },
                        _react2.default.createElement(
                            "div",
                            { className: "title" },
                            _react2.default.createElement(
                                "span",
                                null,
                                _react2.default.createElement("img", { src: "/src/images/latest.png" })
                            ),
                            "\u70ED\u95E8\u8BDD\u9898"
                        ),
                        _react2.default.createElement(
                            "div",
                            { className: "content" },
                            _react2.default.createElement(
                                "div",
                                { className: "citemswrap" },
                                LatestDynamicList
                            ),
                            _react2.default.createElement(
                                "div",
                                { className: "Formore1" },
                                _react2.default.createElement(
                                    _reactRouter.Link,
                                    { to: "/topic" },
                                    "\u66F4\u591A\u8BDD\u9898"
                                )
                            )
                        )
                    ),
                    _react2.default.createElement(
                        "div",
                        { id: "latest" },
                        _react2.default.createElement(
                            "div",
                            { className: "title" },
                            _react2.default.createElement(
                                "span",
                                null,
                                _react2.default.createElement("img", { src: "/src/images/latest.png" })
                            ),
                            "\u7CBE\u54C1\u56DE\u7B54"
                        ),
                        AnswerMainList,
                        nomore ? "" : _react2.default.createElement(
                            "div",
                            { className: "Formore", onClick: function onClick() {

                                    _this5.getMore();
                                }
                            },
                            !getmore ? _react2.default.createElement(_LoadingMore2.default, null) : "加载更多"
                        ),
                        nomore ? _react2.default.createElement(
                            "p",
                            { className: "nomore" },
                            "\u6CA1\u6709\u66F4\u591A\u4E86..."
                        ) : ""
                    )
                )
            );
        }
    }]);

    return ZhaoDaDiscover;
}(_react2.default.Component);

exports.default = ZhaoDaDiscover;

/***/ }),

/***/ 552:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(556);
if(typeof content === 'string') content = [[module.i, content, '']];
// add the styles to the DOM
var update = __webpack_require__(1)(content, {});
if(content.locals) module.exports = content.locals;
// Hot Module Replacement
if(false) {
	// When the styles change, update the <style> tags
	if(!content.locals) {
		module.hot.accept("!!../../../../node_modules/.0.26.4@css-loader/index.js?minimize!../../../../node_modules/.6.0.6@sass-loader/lib/loader.js!./ZhaoDaDiscover.scss", function() {
			var newContent = require("!!../../../../node_modules/.0.26.4@css-loader/index.js?minimize!../../../../node_modules/.6.0.6@sass-loader/lib/loader.js!./ZhaoDaDiscover.scss");
			if(typeof newContent === 'string') newContent = [[module.id, newContent, '']];
			update(newContent);
		});
	}
	// When the module is disposed, remove the <style> tags
	module.hot.dispose(function() { update(); });
}

/***/ }),

/***/ 556:
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(2)();
// imports


// module
exports.push([module.i, ".ZhaoDaDiscover{margin-bottom:.72rem}.ZhaoDaDiscover #dynamic{width:100%;background:#f8f8f8;font-size:0}.ZhaoDaDiscover #dynamic .title{font-family:\\\\82F9\\65B9;font-size:.16rem;font-weight:700;color:#666;background:#f8f8f8;display:flex;align-items:center;padding:.13rem .14rem .12rem}.ZhaoDaDiscover #dynamic .title img{width:.15rem;height:.18rem;display:flex;float:left;margin-right:.06rem}.ZhaoDaDiscover #dynamic .content{border:.01rem solid #d8d8d8;background:#fff;padding-bottom:.1rem}.ZhaoDaDiscover #dynamic .content .citemswrap{display:-webkit-flex;display:-moz-flex;display:-ms-flex;display:-o-flex;display:flex;justify-content:space-around;flex-wrap:wrap}.ZhaoDaDiscover #dynamic .content .Citems{width:1.73rem;height:.6rem;border:.01rem solid #d8d8d8;background:#fff;position:relative;display:inline-block;box-sizing:border-box;margin-top:.13rem;font-size:0}.ZhaoDaDiscover #dynamic .content .Citems .img{display:block;width:.6rem;height:.6rem;background:#e5e5e5}.ZhaoDaDiscover #dynamic .content .Citems .img img{width:.6rem;height:.6rem}.ZhaoDaDiscover #dynamic .content .Citems .detail{display:flex;flex-direction:column;justify-content:space-around;width:1.13rem;height:.6rem;position:absolute;top:0;left:.6rem;padding:.06rem 0;box-sizing:border-box}.ZhaoDaDiscover #dynamic .content .Citems .detail .theme{width:100%;font-family:\\\\82F9\\65B9;font-size:.16rem;font-weight:700;color:#666}.ZhaoDaDiscover #dynamic .content .Citems .detail .span2{display:inline-block;width:93%;padding-left:7%;height:.14rem;line-height:.14rem;font-size:.14rem;font-family:\\\\82F9\\65B9;font-weight:700;color:#333}.ZhaoDaDiscover #dynamic .content .Citems .detail .care{width:93%;display:block;font-family:\\\\82F9\\65B9;font-size:.115rem;color:#adadad;padding-left:7%}.ZhaoDaDiscover #dynamic .content .Citems .detail .care span:nth-of-type(2){margin-left:.06rem}.ZhaoDaDiscover #dynamic .content .Formore1{height:.4rem;border:.01rem solid #21c6cd;color:#666;font-size:.14rem;text-align:center;line-height:.4rem;border-radius:.05rem;margin:.15rem .05rem .1rem;background:#fff}.ZhaoDaDiscover #dynamic .content .Formore1 a{color:#21c6cd}.ZhaoDaDiscover #latest .Formore{width:92%;height:.4rem;border:.01rem solid #21c5cd;color:#21c5cd;font-size:.14rem;text-align:center;line-height:.4rem;border-radius:.05rem;margin:.3rem auto 0}.ZhaoDaDiscover #latest .Formore a{color:#21c5cd}.ZhaoDaDiscover #latest .nomore{font-size:.14rem;color:#adadad;text-align:center}", ""]);

// exports


/***/ })

});