import React from "react";

class ZhiGuan extends React.Component {
    render () {

        return <h1 style={{"fontSize": "0.1rem"}}>职官页面</h1>;

    }
}

export default ZhiGuan;
